// client_app.cc

#include "client_app.hpp"
#include <charlie_messages.hpp>
#include <cstdio>

ClientApp::ClientApp()
   : mouse_(window_.mouse_)
   , keyboard_(window_.keyboard_)
{
}

bool ClientApp::on_init()
{
   if (!network_.initialize({})) {
      return false;
   }

   connection_.set_listener(this);
   connection_.connect(network::IPAddress(192, 168, 0, 102, 54345));

   return true;
}

void ClientApp::on_exit()
{
}

bool ClientApp::on_tick(const Time &dt)
{
   if (keyboard_.pressed(Keyboard::Key::Escape)) {
      return false;
   }

   return true;
}

void ClientApp::on_draw()
{
   renderer_.render_text({ 2, 2 }, Color::White, 1, "CLIENT");
}

void ClientApp::on_acknowledge(network::Connection *connection, 
                               const uint16 sequence)
{
}

void ClientApp::on_receive(network::Connection *connection, 
                           network::NetworkStreamReader &reader)
{
   network::NetworkMessageServerTick message;
   if (!message.read(reader)) {
      assert(!"could not read message!");
   }

   printf("NFO: %llu %u\n", 
          message.server_time_, 
          message.server_tick_);
}

void ClientApp::on_send(network::Connection *connection, 
                        const uint16 sequence, 
                        network::NetworkStreamWriter &writer)
{
}
